﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Emgu.CV;           //for emguCV
using Emgu.CV.Structure; //for Bgr
using Emgu.CV.CvEnum;
using Emgu.Util;
using AForge;
using AForge.Math;
using AForge.Imaging;
using AForge.Imaging.ComplexFilters;
using System.Drawing.Imaging;
using AForge.Imaging.Filters;
namespace HW5t05902128
{

    public partial class Form1 : Form
    {
        public Image<Bgr, Byte> SourceImage { get; set; }
        public Image<Bgr, Byte> SourceImagef { get; set; }
        public Image<Bgr, Byte> ReferenceImage { get; set; }
        public Form1()
        {
            InitializeComponent();
        }


       
        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Load(openFileDialog1.FileName);

                String SourceFileName = openFileDialog1.FileName;
                SourceImage = new Image<Bgr, byte>(SourceFileName);
                pictureBox2.Image = SourceImage.ToBitmap();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Image<Rgb, Byte> Image = new Image<Rgb, Byte>((Bitmap)(pictureBox1.Image));
            Image<Rgb, Byte> gauss = Image.SmoothGaussian(3, 3, 34.3, 45.3);
            pictureBox2.Image = gauss.ToBitmap();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> gray = new Image<Gray, byte>((Bitmap)(pictureBox2.Image));
            Image<Gray, float> sobel = gray.Sobel(0, 1, 3).Add(gray.Sobel(1, 0, 3)).AbsDiff(new Gray(0.0));
            pictureBox2.Image = sobel.ToBitmap();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Image<Rgb, Byte> Image = new Image<Rgb, Byte>((Bitmap)(pictureBox1.Image));
            Image<Rgb, Byte> gauss = Image.SmoothMedian(3);
            pictureBox2.Image = gauss.ToBitmap();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> gray = new Image<Gray, byte>((Bitmap)(pictureBox2.Image));
            Image<Gray, float> sobel = gray.Sobel(0, 1, 3).AbsDiff(new Gray(0.0));
            pictureBox2.Image = sobel.ToBitmap();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Bitmap Im = (Bitmap)pictureBox2.Image;


            ComplexImage complexImage = ComplexImage.FromBitmap(Im);
            // do forward Fourier transformation
            complexImage.ForwardFourierTransform();
            // create filter
         
            
            
            Bitmap fourierImage = complexImage.ToBitmap();
            pictureBox2.Image = fourierImage;

           

            

        }
        private Image<Gray, float> FFT2D(Image<Gray, float> SourceGrayDoubleImage)
        {
            Image<Gray, float> FFTImage = new Image<Gray, float>(SourceGrayDoubleImage.Width, SourceGrayDoubleImage.Height);
            System.Drawing.Point minloc = new System.Drawing.Point();
            System.Drawing.Point maxloc = new System.Drawing.Point();
            double minval = 0, maxval = 0;
            IntPtr SourceComplexImage = CvInvoke.cvCreateImage(SourceGrayDoubleImage.Size, Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_32F, 2);
            CvInvoke.cvSetImageCOI(SourceComplexImage, 1);
            CvInvoke.cvCopy(SourceGrayDoubleImage, SourceComplexImage, IntPtr.Zero);
            CvInvoke.cvSetImageCOI(SourceComplexImage, 0);
            Matrix<float> dft = new Matrix<float>(SourceGrayDoubleImage.Rows, SourceGrayDoubleImage.Cols, 2);
            CvInvoke.cvDFT(SourceComplexImage, dft, Emgu.CV.CvEnum.CV_DXT.CV_DXT_FORWARD, 0);
            Matrix<float> outReal = new Matrix<float>(dft.Size);
            Matrix<float> outIm = new Matrix<float>(dft.Size);
            CvInvoke.cvSplit(dft, outReal, outIm, IntPtr.Zero, IntPtr.Zero);
            // Compute the magnitude of the spectrum Mag = sqrt(Re^2 + Im^2)
            CvInvoke.cvPow(outReal, outReal, 2.0);
            CvInvoke.cvPow(outIm, outIm, 2.0);
            CvInvoke.cvAdd(outReal, outIm, outReal, IntPtr.Zero);
            CvInvoke.cvPow(outReal, outReal, 0.5);

            // Compute log(1 + Mag)
            CvInvoke.cvAddS(outReal, new MCvScalar(1), outReal, IntPtr.Zero); // 1 + Mag
            CvInvoke.cvLog(outReal, outReal); // log(1 + Mag)
            Matrix<float> shift_real = new Matrix<float>(dft.Size);
            cvShiftDFT(outReal, shift_real);
            CvInvoke.cvMinMaxLoc(shift_real, ref minval, ref maxval, ref minloc, ref maxloc, IntPtr.Zero);
            CvInvoke.cvCvtScale(shift_real, shift_real, 1.0 / (maxval - minval), 1.0 * (-minval) / (maxval - minval));
            shift_real.GetSubRect(new Rectangle(System.Drawing.Point.Empty, shift_real.Size)).CopyTo(FFTImage);
            return FFTImage;
        }

        private Image<Gray, float> FFT2DA(Image<Gray, float> SourceGrayDoubleImage)
        {
            Image<Gray, float> FFTImage = new Image<Gray, float>(SourceGrayDoubleImage.Width, SourceGrayDoubleImage.Height);
            System.Drawing.Point minloc = new System.Drawing.Point();
            System.Drawing.Point maxloc = new System.Drawing.Point();
            double minval = 0, maxval = 0;
            IntPtr SourceComplexImage = CvInvoke.cvCreateImage(SourceGrayDoubleImage.Size, Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_32F, 2);
            CvInvoke.cvSetImageCOI(SourceComplexImage, 1);
            CvInvoke.cvCopy(SourceGrayDoubleImage, SourceComplexImage, IntPtr.Zero);
            CvInvoke.cvSetImageCOI(SourceComplexImage, 0);
            Matrix<float> dft = new Matrix<float>(SourceGrayDoubleImage.Rows, SourceGrayDoubleImage.Cols, 2);
            CvInvoke.cvDFT(SourceComplexImage, dft, Emgu.CV.CvEnum.CV_DXT.CV_DXT_FORWARD, 0);
            Matrix<float> outReal = new Matrix<float>(dft.Size);
            Matrix<float> outIm = new Matrix<float>(dft.Size);
            CvInvoke.cvSplit(dft, outReal, outIm, IntPtr.Zero, IntPtr.Zero);
            // Compute the magnitude of the spectrum Mag = sqrt(Re^2 + Im^2)
            CvInvoke.cvPow(outReal, outReal, 2.0);
            CvInvoke.cvPow(outIm, outIm, 2.0);
            CvInvoke.cvAdd(outReal, outIm, outReal, IntPtr.Zero);
            CvInvoke.cvPow(outReal, outReal, 0.5);



            Matrix<float> shift_real = new Matrix<float>(dft.Size);
            cvShiftDFT(outReal, shift_real);
            CvInvoke.cvMinMaxLoc(shift_real, ref minval, ref maxval, ref minloc, ref maxloc, IntPtr.Zero);
            CvInvoke.cvCvtScale(shift_real, shift_real, 1.0 / (maxval - minval), 1.0 * (-minval) / (maxval - minval));
            shift_real.GetSubRect(new Rectangle(System.Drawing.Point.Empty, shift_real.Size)).CopyTo(FFTImage);
            return FFTImage;
        }

        int cvShiftDFT(Matrix<float> src_arr, Matrix<float> dst_arr)
        {
            Matrix<float> q1 = new Matrix<float>(dst_arr.Width / 2, dst_arr.Height / 2);
            Matrix<float> q2 = new Matrix<float>(dst_arr.Width / 2, dst_arr.Height / 2);
            Matrix<float> q3 = new Matrix<float>(dst_arr.Width, dst_arr.Height);
            Matrix<float> q4 = new Matrix<float>(dst_arr.Width, dst_arr.Height);
            Matrix<float> d1 = new Matrix<float>(dst_arr.Width, dst_arr.Height);
            Matrix<float> d2 = new Matrix<float>(dst_arr.Width, dst_arr.Height);
            Matrix<float> d3 = new Matrix<float>(dst_arr.Width, dst_arr.Height);
            Matrix<float> d4 = new Matrix<float>(dst_arr.Width, dst_arr.Height);
            Matrix<float> tmp = new Matrix<float>(src_arr.Size); ;

            int cx, cy;

            if (dst_arr.Width != src_arr.Width ||
               dst_arr.Height != src_arr.Height)
            {
                return 0;
            }

            cx = dst_arr.Width / 2;
            cy = dst_arr.Height / 2; // image center
            q1 = src_arr.GetSubRect(new Rectangle(0, 0, cx, cy));
            q2 = src_arr.GetSubRect(new Rectangle(cx, 0, cx, cy));
            q3 = src_arr.GetSubRect(new Rectangle(cx, cy, cx, cy));
            q4 = src_arr.GetSubRect(new Rectangle(0, cy, cx, cy));
            d1 = dst_arr.GetSubRect(new Rectangle(0, 0, cx, cy));
            d2 = dst_arr.GetSubRect(new Rectangle(cx, 0, cx, cy));
            d3 = dst_arr.GetSubRect(new Rectangle(cx, cy, cx, cy));
            d4 = dst_arr.GetSubRect(new Rectangle(0, cy, cx, cy));

            q3.GetSubRect(new Rectangle(System.Drawing.Point.Empty, q3.Size)).CopyTo(d1);
            q4.GetSubRect(new Rectangle(System.Drawing.Point.Empty, q3.Size)).CopyTo(d2);
            q1.GetSubRect(new Rectangle(System.Drawing.Point.Empty, q3.Size)).CopyTo(d3);
            q2.GetSubRect(new Rectangle(System.Drawing.Point.Empty, q3.Size)).CopyTo(d4);
            return 1;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            Bitmap Im = (Bitmap)pictureBox2.Image;
            
            
            ComplexImage complexImage = ComplexImage.FromBitmap(Im);
            // do forward Fourier transformation
           complexImage.ForwardFourierTransform();
            // create filter
            FrequencyFilter filter = new FrequencyFilter(new IntRange(30, 256));
            // apply filter
           filter.Apply(complexImage);
            // do backward Fourier transformation
           complexImage.BackwardFourierTransform();
            // get complex image as bitmat
            Bitmap fourierImage = complexImage.ToBitmap();
            pictureBox2.Image = fourierImage;
          // Image<Gray, float> SourceGrayDoubleImage = SourceImage.Convert<Gray, float>();
           //Image<Gray, float> FFT2DImage = FFT2D(SourceGrayDoubleImage);
           //Image<Gray, float> FFT2DImagec = INFFT(SourceGrayDoubleImage);
          // CvInvoke.cvShowImage("FFTImage", FFT2DImagec);

        }

        private Image<Gray, float> INFFT(Image<Gray, float> SourceGrayDoubleImage)
        {
            Image<Gray, float> FFTImage = new Image<Gray, float>(SourceGrayDoubleImage.Width, SourceGrayDoubleImage.Height);
            System.Drawing.Point minloc = new System.Drawing.Point();
            System.Drawing.Point maxloc = new System.Drawing.Point();
            double minval = 0, maxval = 0;
            IntPtr SourceComplexImage = CvInvoke.cvCreateImage(SourceGrayDoubleImage.Size, Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_32F, 2);
            IntPtr SourceComplexImagef = CvInvoke.cvCreateImage(SourceGrayDoubleImage.Size, Emgu.CV.CvEnum.IPL_DEPTH.IPL_DEPTH_32F, 2);
            CvInvoke.cvSetImageCOI(SourceComplexImage, 1);
            CvInvoke.cvCopy(SourceGrayDoubleImage, SourceComplexImage, IntPtr.Zero);
            CvInvoke.cvSetImageCOI(SourceComplexImage, 0);
            Matrix<float> dft = new Matrix<float>(SourceGrayDoubleImage.Rows, SourceGrayDoubleImage.Cols, 2);

            Matrix<float> idft = new Matrix<float>(SourceGrayDoubleImage.Rows, SourceGrayDoubleImage.Cols, 2);
            CvInvoke.cvDFT(SourceComplexImage, dft, Emgu.CV.CvEnum.CV_DXT.CV_DXT_FORWARD, 0);
           // CvInvoke.cvAdd(SourceComplexImage, SourceComplexImagef, dft, IntPtr.Zero);
            CvInvoke.cvDFT(dft, idft, Emgu.CV.CvEnum.CV_DXT.CV_DXT_INVERSE, 0);

            Matrix<float> outReal = new Matrix<float>(idft.Size);
            Matrix<float> outIm = new Matrix<float>(idft.Size);
            CvInvoke.cvSplit(idft, outReal, outIm, IntPtr.Zero, IntPtr.Zero);
            //CvInvoke.cvAdd(outReal , SourceComplexImagef, outReal , IntPtr.Zero);
            //CvInvoke.cvAdd(outIm , SourceComplexImagef, outIm , IntPtr.Zero);
            // Compute the magnitude of the spectrum Mag = sqrt(Re^2 + Im^2)
            CvInvoke.cvPow(outReal, outReal, 2.0);
            CvInvoke.cvPow(outIm, outIm, 2.0);
            CvInvoke.cvAdd(outReal, outIm, outReal, IntPtr.Zero);
            CvInvoke.cvPow(outReal, outReal, 0.5);



            Matrix<float> shift_real = new Matrix<float>(idft.Size);
            shift_real = outReal;

            CvInvoke.cvMinMaxLoc(shift_real, ref minval, ref maxval, ref minloc, ref maxloc, IntPtr.Zero);
            CvInvoke.cvCvtScale(shift_real, shift_real, 1.0 / (maxval - minval), 1.0 * (-minval) / (maxval - minval));
            shift_real.GetSubRect(new Rectangle(System.Drawing.Point.Empty, shift_real.Size)).CopyTo(FFTImage);
            return FFTImage;
        }

        private Image<Gray, float> newImage(Image<Gray, float> image1, Image<Gray, float> image2)
        {
            int ImageWidth = 0;
            int ImageHeight = 0;

            //get max width
            if (image1.Width > image2.Width)
                ImageWidth = image1.Width;
            else
                ImageWidth = image2.Width;

            //calculate new height
            ImageHeight = image1.Height + image2.Height;

            //declare new image (large image).
            Image<Gray, float> imageResult;

            Bitmap bitmap = new Bitmap(Math.Max(image1.Width, image2.Width), image1.Height + image2.Height);
            using (Graphics g = Graphics.FromImage(bitmap))
            {
                g.DrawImage(image1.Bitmap, 0, 0);
                g.DrawImage(image2.Bitmap, 0, image1.Height);

            }

            imageResult = new Image<Gray, float>(bitmap);



            return imageResult;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            Bitmap image = (Bitmap)pictureBox2.Image;
            Grayscale filter = new Grayscale(0.2125, 0.7154, 0.0721);
            // apply the filter
            Bitmap grayImage = filter.Apply(image);
            pictureBox2.Image = grayImage;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Bitmap Im = (Bitmap)pictureBox2.Image;


            ComplexImage complexImage = ComplexImage.FromBitmap(Im);
            // do forward Fourier transformation
            complexImage.ForwardFourierTransform();
            Bitmap FFT = complexImage.ToBitmap();
            
            // create filter
            FrequencyFilter filter = new FrequencyFilter(new IntRange(20,40 ));
            // apply filter
            filter.Apply(complexImage);
            // do backward Fourier transformation
            complexImage.BackwardFourierTransform();
            // get complex image as bitmat
            Bitmap fourierImage = complexImage.ToBitmap();
           
            pictureBox2.Image = fourierImage;

            
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Bitmap ima = (Bitmap)pictureBox2.Image;
            SaveFileDialog sfd = new SaveFileDialog();
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ima.Save(sfd.FileName);  
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Bitmap Im = (Bitmap)pictureBox2.Image;


            ComplexImage complexImage = ComplexImage.FromBitmap(Im);
            // do forward Fourier transformation
            complexImage.ForwardFourierTransform();
            Bitmap FFT = complexImage.ToBitmap();

            // create filter
            FrequencyFilter filter = new FrequencyFilter(new IntRange(0, 40));
            // apply filter
            filter.Apply(complexImage);
            // do backward Fourier transformation
            complexImage.BackwardFourierTransform();
            // get complex image as bitmat
            Bitmap fourierImage = complexImage.ToBitmap();

            pictureBox2.Image = fourierImage;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Bitmap image =(Bitmap ) pictureBox2.Image;
            ColorFiltering filter = new ColorFiltering();
            // set color ranges to keep
            filter.Red = new IntRange(0,75);
            filter.Green = new IntRange(0, 75);
            filter.Blue = new IntRange(0,255);
            // apply the filter
            filter.ApplyInPlace(image);

            pictureBox2.Image = image;

        }


        
         
    }
}
namespace AForge.Imaging.ComplexFilters
{
    using System;
    using AForge;
    using AForge.Math;

    /// <summary>
    /// Filtering of frequencies outside of specified range in complex Fourier
    /// transformed image.
    /// </summary>
    /// 
    /// <remarks><para>The filer keeps only specified range of frequencies in complex
    /// Fourier transformed image. The rest of frequencies are zeroed.</para>
    /// 
    /// <para>Sample usage:</para>
    /// <code>
    /// // create complex image
    /// ComplexImage complexImage = ComplexImage.FromBitmap( image );
    /// // do forward Fourier transformation
    /// complexImage.ForwardFourierTransform( );
    /// // create filter
    /// FrequencyFilter filter = new FrequencyFilter( new IntRange( 20, 128 ) );
    /// // apply filter
    /// filter.Apply( complexImage );
    /// // do backward Fourier transformation
    /// complexImage.BackwardFourierTransform( );
    /// // get complex image as bitmat
    /// Bitmap fourierImage = complexImage.ToBitmap( );
    /// </code>
    /// 
    /// <para><b>Initial image:</b></para>
    /// <img src="img/imaging/sample3.jpg" width="256" height="256" />
    /// <para><b>Fourier image:</b></para>
    /// <img src="img/imaging/frequency_filter.jpg" width="256" height="256" />
    /// </remarks>
    /// 
    public class FrequencyFilter : IComplexFilter
    {
        private IntRange frequencyRange = new IntRange(0, 1024);

        /// <summary>
        /// Range of frequencies to keep.
        /// </summary>
        /// 
        /// <remarks><para>The range specifies the range of frequencies to keep. Values is frequencies
        /// outside of this range are zeroed.</para>
        /// 
        /// <para>Default value is set to <b>[0, 1024]</b>.</para></remarks>
        /// 
        public IntRange FrequencyRange
        {
            get { return frequencyRange; }
            set { frequencyRange = value; }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FrequencyFilter"/> class.
        /// </summary>
        /// 
        public FrequencyFilter() { }

        /// <summary>
        /// Initializes a new instance of the <see cref="FrequencyFilter"/> class.
        /// </summary>
        /// 
        /// <param name="frequencyRange">Range of frequencies to keep.</param>
        /// 
        public FrequencyFilter(IntRange frequencyRange)
        {
            this.frequencyRange = frequencyRange;
        }

        /// <summary>
        /// Apply filter to complex image.
        /// </summary>
        /// 
        /// <param name="complexImage">Complex image to apply filter to.</param>
        /// 
        /// <exception cref="ArgumentException">The source complex image should be Fourier transformed.</exception>
        /// 
        public void Apply(ComplexImage complexImage)
        {
            if (!complexImage.FourierTransformed)
            {
                throw new ArgumentException("The source complex image should be Fourier transformed.");
            }

            // get image dimenstion
            int width = complexImage.Width;
            int height = complexImage.Height;

            // half of dimensions
            int hw = width >> 1;
            int hh = height >> 1;

            // min and max frequencies
            int min = frequencyRange.Min;
            int max = frequencyRange.Max;

            // complex data to process
            Complex[,] data = complexImage.Data;

            // process all data
            for (int i = 0; i < height; i++)
            {
                int y = i - hh;

                for (int j = 0; j < width; j++)
                {
                    int x = j - hw;
                    int d = (int)Math.Sqrt(x * x + y * y);

                    // filter values outside the range
                    if ((d < max) && (d > min))
                    {
                        data[i, j].Re = 0;
                        data[i, j].Im = 0;
                    }
                }
            }
        }
    }
}
